#include <iostream>
#include <stdexcept>
using namespace std;

// NODE + CLASS: lab-style names; T is the type of stored item.
template <class T> class Stack {
private:
    typedef struct stackNode {
        struct stackNode* next;
        T theItem;
    } StackNode;
    StackNode* topOfStack;
    int count;
public:
    Stack() : topOfStack(nullptr), count(0) {}
    bool isEmpty() const { return count == 0; }
    int size() const { return count; }
    void push(T item) {
        StackNode* newNode = new StackNode{topOfStack, item};
        topOfStack = newNode; // New node points to the previous top.
        ++count;
    }
    T pop() {
        if (isEmpty()) throw runtime_error("Empty stack");
        T item = topOfStack->theItem; // Save data before deleting its node.
        StackNode* old = topOfStack;
        topOfStack = old->next;
        delete old;
        --count;
        return item;
    }
    T top() const {
        if (isEmpty()) throw runtime_error("Empty stack");
        return topOfStack->theItem;
    }
    ~Stack() { while (!isEmpty()) pop(); }
    // Prevent two stacks from owning the same nodes.
    Stack(const Stack&) = delete;
    Stack& operator=(const Stack&) = delete;
};

// FREE FUNCTION: EDIT HERE for counting, summing, or searching questions.
int countAbove(Stack<int>& stack, int limit) {
    int result = 0;
    Stack<int> temporary;
    while (!stack.isEmpty()) {
        int value = stack.pop();
        if (value > limit) ++result;
        temporary.push(value);
    }
    // A second reversal restores the original order.
    while (!temporary.isEmpty()) stack.push(temporary.pop());
    return result;
}

int main() {
    // EDIT HERE: input values and function call.
    Stack<int> stack;
    stack.push(4); stack.push(9); stack.push(2); stack.push(7);
    cout << countAbove(stack, 5) << endl;
    while (!stack.isEmpty()) cout << stack.pop() << ' ';
    cout << endl;
    return 0;
}
