FOUR C++ LAB-STYLE STARTERS — Visual Studio 2022

Open MidtermStarters.sln. Requires the Desktop development with C++ workload.
Right-click the desired project > Set as Startup Project. Ctrl+F5 runs it.
Each project is independent. Never combine all four main.cpp files in one project.
If using a newer Visual Studio, accept retargeting to your installed toolset.

01 Inheritance Single: main.cpp only; abstract base + two derived classes.
02 Stack Single: main.cpp only; template linked stack + countAbove.
03 Inheritance Split: main.cpp + Shapes.h + Shapes.cpp; same example as 01.
04 Queue Split: main.cpp + Queue.h + Queue.cpp; linked queue + countAbove.

WHERE TO EDIT
main.cpp: test objects, inputs, calls, and printing.
.h: class fields and function declarations (what exists).
.cpp: function definitions (how it works); use ClassName:: for member functions.
Both .cpp files include the header; Visual Studio compiles and links them.
Do NOT #include a .cpp file. Add declarations to the header when adding methods.
Template class implementations normally stay in the header or same file, so
02 is single-file and 04 deliberately uses int rather than a class template.

These are minimal working adaptation templates, not complete official lab solutions.
Find EDIT HERE comments to change fields, constructors, operations, and test data.
All use using namespace std as requested.

EXPECTED OUTPUT
01 and 03: 12 then 12.5664
02: 2 then 7 2 9 4
04: 2 then 4 9 2 7

The stack uses the lab names StackNode, stackNode, topOfStack, theItem, count.
It uses standard runtime_error to keep the starter small.
The inheritance starter simplifies the Shape lab to area calculations.
Copying containers is disabled to avoid sharing owned node pointers.
