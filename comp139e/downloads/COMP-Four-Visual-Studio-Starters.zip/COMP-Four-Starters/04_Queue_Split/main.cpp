#include <iostream>
#include "Queue.h" // Include declarations, never include Queue.cpp.
using namespace std;

int main() {
    // EDIT HERE: test input and the operation requested by the question.
    Queue queue;
    queue.enqueue(4); queue.enqueue(9); queue.enqueue(2); queue.enqueue(7);
    cout << countAbove(queue, 5) << endl;
    while (!queue.isEmpty()) cout << queue.dequeue() << ' ';
    cout << endl;
    return 0;
}
