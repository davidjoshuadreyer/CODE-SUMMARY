#ifndef QUEUE_H
#define QUEUE_H
#include <stdexcept>
using namespace std;

// Linked integer queue. EDIT HERE: add declarations for required operations.
class Queue {
private:
    struct QueueNode {
        int theItem;
        QueueNode* next;
    };
    QueueNode* head; // Remove from front.
    QueueNode* tail; // Add at back.
    int count;
public:
    Queue();
    ~Queue();
    void enqueue(int item);
    int dequeue();
    int front() const;
    bool isEmpty() const;
    int size() const;
    Queue(const Queue&) = delete;
    Queue& operator=(const Queue&) = delete;
};
// Free function: declaration goes here; body goes in Queue.cpp.
int countAbove(Queue& queue, int limit);
#endif
