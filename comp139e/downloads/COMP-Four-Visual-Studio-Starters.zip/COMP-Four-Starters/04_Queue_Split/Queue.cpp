#include "Queue.h"
#include <stdexcept>
using namespace std;

Queue::Queue() : head(nullptr), tail(nullptr), count(0) {}
Queue::~Queue() { while (!isEmpty()) dequeue(); }
bool Queue::isEmpty() const { return count == 0; }
int Queue::size() const { return count; }
void Queue::enqueue(int item) {
    QueueNode* newNode = new QueueNode{item, nullptr};
    if (isEmpty()) head = newNode; // First node is both head and tail.
    else tail->next = newNode;
    tail = newNode;
    ++count;
}
int Queue::dequeue() {
    if (isEmpty()) throw runtime_error("Empty queue");
    QueueNode* old = head;
    int item = old->theItem;
    head = old->next;
    delete old;
    --count;
    if (isEmpty()) tail = nullptr; // Do not leave tail pointing at freed memory.
    return item;
}
int Queue::front() const {
    if (isEmpty()) throw runtime_error("Empty queue");
    return head->theItem;
}
// EDIT HERE: change the condition to count other kinds of values.
int countAbove(Queue& queue, int limit) {
    int result = 0;
    int originalSize = queue.size();
    for (int i = 0; i < originalSize; ++i) {
        int value = queue.dequeue();
        if (value > limit) ++result;
        queue.enqueue(value); // One full rotation restores original order.
    }
    return result;
}
