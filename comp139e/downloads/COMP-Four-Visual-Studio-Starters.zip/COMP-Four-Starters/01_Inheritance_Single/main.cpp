#include <iostream>
using namespace std;

// BASE CLASS: shared state and the interface for derived classes.
class Shape {
protected:
    int id; // EDIT HERE: shared fields.
public:
    explicit Shape(int number) : id(number) {}
    virtual double getArea() const = 0; // Derived classes must implement this.
    virtual ~Shape() = default;
};

// DERIVED CLASS: inherits id and supplies its own area calculation.
class Rectangle : public Shape {
private:
    double length, width; // EDIT HERE: fields specific to this class.
public:
    Rectangle(int number, double l, double w)
        : Shape(number), length(l), width(w) {} // Initialize base first.
    double getArea() const override { return length * width; }
};

// SECOND DERIVED CLASS: same interface, different calculation.
class Circle : public Shape {
private:
    double radius;
public:
    Circle(int number, double r) : Shape(number), radius(r) {}
    double getArea() const override { return 3.14159 * radius * radius; }
};

int main() {
    // EDIT HERE: create objects and test the required operations.
    Rectangle rectangle(1, 3, 4);
    Circle circle(2, 2);
    Shape* shapes[] = { &rectangle, &circle };
    for (Shape* shape : shapes)
        cout << shape->getArea() << endl; // Calls the actual derived method.
    return 0; // Objects above clean themselves up; do not delete these pointers.
}
