#include <iostream>
#include "Shapes.h"
using namespace std;

int main() {
    // EDIT HERE: create objects and test the required operations.
    Rectangle rectangle(1, 3, 4);
    Circle circle(2, 2);
    Shape* shapes[] = { &rectangle, &circle };
    for (Shape* shape : shapes)
        cout << shape->getArea() << endl; // Calls the actual derived method.
    return 0; // Objects above clean themselves up; do not delete these pointers.
}
