#include "Shapes.h"
using namespace std;

// DEFINITIONS: ClassName:: says which class owns each function.
Shape::Shape(int number) : id(number) {}
Shape::~Shape() = default;

// EDIT HERE: constructor parameters must match the header.
Rectangle::Rectangle(int number, double l, double w)
    : Shape(number), length(l), width(w) {}
double Rectangle::getArea() const { return length * width; }

Circle::Circle(int number, double r) : Shape(number), radius(r) {}
double Circle::getArea() const { return 3.14159 * radius * radius; }
