#ifndef SHAPES_H
#define SHAPES_H
#include <iostream>
using namespace std;

// DECLARATIONS: fields and function signatures belong here.
class Shape {
protected:
    int id; // EDIT HERE: data shared by derived classes.
public:
    explicit Shape(int number);
    virtual double getArea() const = 0;
    virtual ~Shape();
};
class Rectangle : public Shape {
private:
    double length, width;
public:
    Rectangle(int number, double l, double w);
    double getArea() const override;
};
class Circle : public Shape {
private:
    double radius;
public:
    Circle(int number, double r);
    double getArea() const override;
};
#endif
