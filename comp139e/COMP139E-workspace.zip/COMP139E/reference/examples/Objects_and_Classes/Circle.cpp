/*
 * Circle.cpp
 *
 *  Created on: Jan. 23, 2022
 *      Author: mao
 */


#include "Circle.h"

// Construct a default circle object
Circle::Circle()
{
	radius = 1;
}

// Construct a circle object
Circle::Circle(double newRadius)
{
	radius = newRadius;
}

// Return the area of this circle
double Circle::getArea()
{
	return radius * radius * 3.14159;
}

